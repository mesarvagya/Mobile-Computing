local physics = require('physics');
physics.start();
physics.setDrawMode('hybrid');
local top = display.newRect(0, 0, display.contentWidth, 20)
top.anchorX = 0; top.anchorY = 0
local bottom = display.newRect(0, display.contentHeight-20, display.contentWidth, 20)
bottom.anchorX = 0; bottom.anchorY = 0
local left = display.newRect(0, 0, 20, display.contentHeight)
left.anchorX = 0; left.anchorY = 0
local right = display.newRect(display.contentWidth-20, 0, 20, display.contentHeight)
right.anchorX = 0; right.anchorY = 0

--physics.addBody(top, 'static')
physics.addBody(bottom, 'static')
physics.addBody(left, 'static')
physics.addBody(right, 'static')



local options = {
	
	frames = {
	{x = 20, y = 3, 
	width = 257, height = 387}

	}
}

local sheet = graphics.newImageSheet("mario.png", options)

--local mario = display.newImage(sheet, 1);

--mario.x = display.contentCenterX;
--mario.y = display.contentCenterY;


--mario.xScale = 0.2;
--mario.yScale = 0.2;
--mario.width = mario.width/4;
--mario.height = mario.height/4;
--mario.rotation = 5;

--local bodyoutline = graphics.newOutline(1, sheet, 1);
--physics.addBody(mario, "dynamic", {outline = bodyoutline});

function mariorain()
	j = display.newImage(sheet, 1);
	joutline = graphics.newOutline(2, sheet, 1);
	j.width = j.width/4;
	j.height = j.height/4;

	physics.addBody(j, "dynamic", {bounce=1, outline = joutline});
	
	j.x = 60 + math.random (160);
	j.y = -100
end

local dropMario = timer.performWithDelay(1000, mariorain, 100)







--[[
local pentagon = display.newPolygon (display.contentCenterX, display.contentCenterY, {
	0,-37, 37, -10, 23, 34, -23, 34, -37, -10
	})

physics.addBody(pentagon, 'dynamic', {shape={0,-37, 37, -10, 23, 34, -23, 34, -37, -10}, 
	density = 3.0, 
	friction = 0.8, bounce= 2  } )
--local ball = display.newCircle(display.contentCenterX, display.contentCenterY, 20)
--local ball = display.newRect(display.contentCenterX, display.contentCenterY, 20,20)
--physics.addBody(ball, 'dynamic', {bounce=1, radius=20});
--physics.setGravity(0,-1);
pentagon:applyForce(0,2, pentagon.x+10, pentagon.y+3)
pentagon:applyTorque(2)
--all:applyTorque(1)
]]