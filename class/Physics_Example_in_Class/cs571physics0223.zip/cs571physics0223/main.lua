local physics = require('physics');
physics.start();
physics.setDrawMode('hybrid');
local top = display.newRect(0, 0, display.contentWidth, 20)
top.anchorX = 0; top.anchorY = 0
local bottom = display.newRect(0, display.contentHeight-20, display.contentWidth, 20)
bottom.anchorX = 0; bottom.anchorY = 0
local left = display.newRect(0, 0, 20, display.contentHeight)
left.anchorX = 0; left.anchorY = 0
local right = display.newRect(display.contentWidth-20, 0, 20, display.contentHeight)
right.anchorX = 0; right.anchorY = 0

physics.addBody(top, 'static')
physics.addBody(bottom, 'static')
physics.addBody(left, 'static')
physics.addBody(right, 'static')

--local ball = display.newCircle(display.contentCenterX, display.contentCenterY, 20)
local ball = display.newRect(display.contentCenterX, display.contentCenterY, 20,20)
physics.addBody(ball, 'dynamic', {bounce=1, radius=20});
physics.setGravity(0, 0);
ball:applyForce(1,-1, ball.x, ball.y)
ball:applyTorque(10)
