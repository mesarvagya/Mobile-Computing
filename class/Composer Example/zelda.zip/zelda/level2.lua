local composer = require( "composer" )
local scene = composer.newScene()
local xx = display.contentWidth
local yy = display.contentHeight
local enemy, e1, e2;
---------------------------------------------------------------------------------
-- All code outside of the listener functions will only be executed ONCE
-- unless "composer.removeScene()" is called.
---------------------------------------------------------------------------------
 
-- local forward references should go here
 
---------------------------------------------------------------------------------
 
-- "scene:create()"
function scene:create( event )
 
   local sceneGroup = self.view
 
   -- Initialize the scene here.
   -- Example: add display objects to "sceneGroup", add touch listeners, etc.

   local options =
   {
      frames = {
         {x =257, y= 0, width =256, height = 168}, 
         {x =513, y= 0, width =256, height = 168}, 
      }
   };

   local sheet = graphics.newImageSheet("zeldaDungeon1.png", options);
   local bg = display.newImage(sheet,2);
   bg.x = display.contentWidth/2;
   bg.y = display.contentHeight/2;
   sceneGroup:insert(bg);

    enemy = display.newGroup();
   e1 = display.newRect(enemy, xx/2-50, yy/2-50, 10, 10)
     e2 = display.newRect(enemy, xx/2+50, yy/2-50, 10, 10)
     e1:setFillColor(0, 1, 0)
     e2:setFillColor(0, 1, 0)
     sceneGroup:insert(enemy)
end



 
-- "scene:show()"
function scene:show( event )
 
   local sceneGroup = self.view
   local phase = event.phase
 
   if ( phase == "will" ) then
      -- Called when the scene is still off screen (but is about to come on screen).
   elseif ( phase == "did" ) then
      -- Called when the scene is now on screen.
      -- Insert code here to make the scene come alive.
      -- Example: start timers, begin animation, play audio, etc.
      local function next(event)
         Runtime:removeEventListener("tap", next)
         composer.gotoScene("level1", {effect="slideRight", time=500});
      end
      Runtime:addEventListener("tap", next);



   end
end
 
-- "scene:hide()"
function scene:hide( event )
 
   local sceneGroup = self.view
   local phase = event.phase
 
   if ( phase == "will" ) then
      -- Called when the scene is on screen (but is about to go off screen).
      -- Insert code here to "pause" the scene.
      -- Example: stop timers, stop animation, stop audio, etc.
   elseif ( phase == "did" ) then
      -- Called immediately after scene goes off screen.
   end
end
 
-- "scene:destroy()"
function scene:destroy( event )
 
   local sceneGroup = self.view
 
   -- Called prior to the removal of scene's view ("sceneGroup").
   -- Insert code here to clean up the scene.
   -- Example: remove display objects, save state, etc.
end
 
---------------------------------------------------------------------------------
 
-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
 
---------------------------------------------------------------------------------
 
return scene