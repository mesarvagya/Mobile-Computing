local composer = require("composer");
display.setStatusBar(display.HiddenStatusBar);

local options={
		effect = "fade",
		time = 800
}

composer.gotoScene("level1", options)