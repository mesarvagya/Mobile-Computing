local composer = require("composer")

display.setStatusBar(display.HiddenStatusBar)

--composer.gotoScene("scene1")




-- Create a background which should appear behind all scenes
--local background = display.newImage( "uah.png" )

-- Create a "health meter" image which should appear above all scenes
local meter = display.newImage( "S_UAH_primary.png" )
--meter.anchorX = 1
--meter.anchorY = 1
meter.x = display.contentCenterX
meter.y = 120

-- Sort everything in the correct z-index order
local stage = display.getCurrentStage()
--stage:insert( background )
stage:insert( composer.stage )
stage:insert( meter )

-- Open the initial scene
composer.gotoScene( "scene1", "fade", 800 )